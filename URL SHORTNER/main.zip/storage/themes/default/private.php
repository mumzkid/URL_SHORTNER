<section>
    <div class="container d-flex flex-column">
        <div class="row align-items-center justify-content-between min-vh-100">
            <div class="col-12 col-md-6 col-xl-6 order-md-1 text-center text-md-left">
                <h6 class="display-1 mb-3 font-weight-600 text-primary"><?php ee('Hello') ?></h6>
                <p class="lead text-lg mb-5">
                    <?php ee('Thanks for your interest but this website is currently used privately.') ?>
                </p>
            </div>
        </div>
    </div>
</section>